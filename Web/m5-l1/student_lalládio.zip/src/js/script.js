var btn = document.getElementById('button')
var subTitle = document.querySelector('.wrapper__subtitle')
btn.addEventListener('click', function () {
    subTitle.textContent = '¡Eso resultó genial!'
})